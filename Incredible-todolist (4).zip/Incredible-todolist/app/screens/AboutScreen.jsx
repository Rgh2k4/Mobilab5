'use client';
import React from "react";
import { Button } from "react-native";
import MainLayout from "../layouts/MainLayout";

export default function AboutScreen({ navigation }) {
    const appName = "Incredible-todolist";
    const developerName = "Robert Hansen";
    const currentDate = new Date().toLocaleDateString();

    return (
        <MainLayout>
            <div className="container mx-auto p-4">
                <h1 className="text-2xl font-bold mb-4">{appName}</h1>
                <p className="text-lg">Developed by: {developerName}</p>
                <p className="text-lg">Date: {currentDate}</p>
                <div className="mt-4">
                    <Button
                        title="Go to Home"
                        onPress={() => navigation.navigate("Home")}
                    />
                </div>
            </div>
        </MainLayout>
    );
}
