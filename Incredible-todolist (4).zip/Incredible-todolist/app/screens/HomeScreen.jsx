'use client';
import React, { useState, useEffect } from "react";
import { getItems, addItem } from "./_services/shopping-list-services";
import { useUserAuth } from "./_utils/auth-context";
import ItemList from "./item-list";
import NewItem from "./new-item";
import { Button } from "react-native";
import MainLayout from "../layouts/MainLayout";

export default function HomeScreen({ navigation }) {
    const { user } = useUserAuth();
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);

    const loadItems = async () => {
        try {
            const fetchedItems = await getItems(user.uid);
            setItems(fetchedItems);
        } catch (error) {
            console.error("Error fetching items:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleAddItem = async (newItem) => {
        try {
            const addedItem = await addItem(user.uid, newItem);
            setItems((prevItems) => [...prevItems, addedItem]);
        } catch (error) {
            console.error("Error adding item:", error);
        }
    };

    useEffect(() => {
        if (user) {
            loadItems();
        }
    }, [user]);

    if (!user) {
        return (
            <MainLayout>
                <p>Please log in to access your to-do list.</p>
            </MainLayout>
        );
    }

    if (loading) {
        return (
            <MainLayout>
                <p>Loading your to-do list...</p>
            </MainLayout>
        );
    }

    return (
        <MainLayout>
            <div className="container mx-auto p-4">
                <h1 className="text-xl font-bold mb-4">Your To-Do List</h1>
                <NewItem onAddItem={handleAddItem} />
                <div className="mt-6">
                    <ItemList
                        items={items}
                        onItemSelect={(itemName) => console.log(itemName)}
                    />
                </div>
                <div className="mt-4">
                    <Button
                        title="Go to About"
                        onPress={() => navigation.navigate("About")}
                    />
                </div>
            </div>
        </MainLayout>
    );
}
