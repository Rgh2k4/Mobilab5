import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const Footer = () => {
  return (
    <View style={styles.footer}>
      <Text style={styles.footerText}> {new Date().getFullYear()} Incredible-todolist</Text>
    </View>
  );
};

const MainLayout = ({ children }) => {
  return (
    <View style={styles.container}>
      {children}
      <Footer />
    </View>
  );
};

const styles = StyleSheet.create({
    task: {
        padding: 10,
        borderBottomWidth: 1,
        borderColor: '#ccc',
    },
    completed: {
        backgroundColor: '#e0e0e0',
    },
    taskText: {
        fontSize: 16,
    },
    form: {
        padding: 10,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    input: {
        padding: 10,
        borderWidth: 1,
        borderColor: '#ccc',
        width: '80%',
    },
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: 'grey',
    },
    footer: {
        backgroundColor: '#000080',
        padding: 10,
        alignItems: 'center',
        marginTop: 'auto',
    },
    footerText: {
        color: 'white',
        fontSize: 14,
    },
});

export default MainLayout;
