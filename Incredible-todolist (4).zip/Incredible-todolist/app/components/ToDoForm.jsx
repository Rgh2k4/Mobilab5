import React from 'react';
import {
  View,
  TextInput,
  Button
} from 'react-native';
import {styles} from './App.js';

function ToDoForm({ addTask }) {
  const [taskText, setTaskText] = React.useState('');
  const handleAddTask = () => {
    if (taskText.trim()) {
      addTask(taskText);
      setTaskText('');
    }
  };
  return (
    <View style={styles.form}>
      <TextInput
      style={styles.input}
      placeholder="Add a new task..."
      onChangeText={(text) => setTaskText(text)}
      value={taskText}
      />
      <Button title="Add Task" onPress={() => addTask(taskText)} />
    </View>
  );
}

<View style={styles.form}>
        <TextInput
          style={styles.input}
          placeholder="Add a new task..."
        />
        <Button title="Add" />
      </View>

export default ToDoForm;